from flask import Flask, request, jsonify
from datetime import datetime

app = Flask(__name__)
app.json.ensure_ascii = False

students_db = {}
next_id = 1


@app.route("/api/students", methods=["GET"])
def get_students():

    students = list(students_db.values())

    group = request.args.get("group")
    min_gpa = request.args.get("min_gpa", type=float)

    sort_by = request.args.get("sort_by", "name")
    order = request.args.get("order", "asc")

    page = request.args.get("page", 1, type=int)
    per_page = request.args.get("per_page", 10, type=int)

    if group:
        students = [
            s for s in students
            if s["group"] == group
        ]

    if min_gpa is not None:
        students = [
            s for s in students
            if s["gpa"] >= min_gpa
        ]

    if sort_by in ["name", "gpa", "group"]:

        reverse = order == "desc"

        students.sort(
            key=lambda x: x[sort_by],
            reverse=reverse
        )

    total = len(students)

    start = (page - 1) * per_page
    end = start + per_page

    students = students[start:end]

    return jsonify({
        "count": total,
        "page": page,
        "per_page": per_page,
        "students": students
    })


@app.route("/api/students", methods=["POST"])
def create_student():

    global next_id

    data = request.get_json()

    if not data:
        return jsonify({
            "error": "Очікується JSON"
        }), 400

    required = [
        "name",
        "group",
        "email",
        "gpa"
    ]

    missing = [
        field for field in required
        if field not in data
    ]

    if missing:
        return jsonify({
            "error": f"Відсутні поля: {', '.join(missing)}"
        }), 400

    if not (0 <= float(data["gpa"]) <= 100):
        return jsonify({
            "error": "GPA повинен бути в межах 0-100"
        }), 422

    email_exists = any(
        s["email"] == data["email"]
        for s in students_db.values()
    )

    if email_exists:
        return jsonify({
            "error": "Email вже існує"
        }), 422

    student = {
        "id": next_id,
        "name": data["name"],
        "group": data["group"],
        "email": data["email"],
        "gpa": float(data["gpa"]),
        "created_at": datetime.now().isoformat()
    }

    students_db[next_id] = student

    next_id += 1

    return jsonify(student), 201


@app.route("/api/students/<int:student_id>",
           methods=["GET"])
def get_student(student_id):

    student = students_db.get(student_id)

    if not student:
        return jsonify({
            "error": "Студента не знайдено"
        }), 404

    return jsonify(student)


@app.route("/api/students/<int:student_id>",
           methods=["PUT"])
def update_student(student_id):

    student = students_db.get(student_id)

    if not student:
        return jsonify({
            "error": "Студента не знайдено"
        }), 404

    data = request.get_json()

    required = [
        "name",
        "group",
        "email",
        "gpa"
    ]

    for field in required:
        if field not in data:
            return jsonify({
                "error": f"Поле {field} обов'язкове"
            }), 400

    if not (0 <= float(data["gpa"]) <= 100):
        return jsonify({
            "error": "Некоректний GPA"
        }), 422

    student.update({
        "name": data["name"],
        "group": data["group"],
        "email": data["email"],
        "gpa": float(data["gpa"])
    })

    return jsonify(student)


@app.route("/api/students/<int:student_id>",
           methods=["PATCH"])
def patch_student(student_id):

    student = students_db.get(student_id)

    if not student:
        return jsonify({
            "error": "Студента не знайдено"
        }), 404

    data = request.get_json()

    if "gpa" in data:

        if not (0 <= float(data["gpa"]) <= 100):
            return jsonify({
                "error": "Некоректний GPA"
            }), 422

    student.update(data)

    return jsonify(student)


@app.route("/api/students/<int:student_id>",
           methods=["DELETE"])
def delete_student(student_id):

    student = students_db.get(student_id)

    if not student:
        return jsonify({
            "error": "Студента не знайдено"
        }), 404

    del students_db[student_id]

    return "", 204


@app.route("/api/students/stats",
           methods=["GET"])
def students_stats():

    students = list(students_db.values())

    total = len(students)

    if total == 0:
        return jsonify({
            "total": 0,
            "avg_gpa": 0,
            "groups": {},
            "top_students": []
        })

    avg_gpa = round(
        sum(s["gpa"] for s in students) / total,
        2
    )

    groups = {}

    for student in students:
        groups[student["group"]] = (
            groups.get(
                student["group"],
                0
            ) + 1
        )

    top_students = sorted(
        students,
        key=lambda x: x["gpa"],
        reverse=True
    )[:3]

    return jsonify({
        "total": total,
        "avg_gpa": avg_gpa,
        "groups": groups,
        "top_students": top_students
    })


@app.errorhandler(404)
def not_found(error):

    return jsonify({
        "error": "Ресурс не знайдено",
        "status": 404
    }), 404


@app.errorhandler(400)
def bad_request(error):

    return jsonify({
        "error": "Некоректний запит",
        "status": 400
    }), 400


@app.errorhandler(422)
def unprocessable(error):

    return jsonify({
        "error": "Помилка валідації",
        "status": 422
    }), 422


if __name__ == "__main__":

    test_students = [
        {
            "name": "Іваненко О.",
            "group": "КІ-21",
            "email": "ivan@kpi.ua",
            "gpa": 85.5
        },
        {
            "name": "Петренко М.",
            "group": "КІ-21",
            "email": "petro@kpi.ua",
            "gpa": 92.0
        },
        {
            "name": "Сидоренко А.",
            "group": "КІ-22",
            "email": "syd@kpi.ua",
            "gpa": 78.3
        },
        {
            "name": "Коваль Л.",
            "group": "КІ-22",
            "email": "koval@kpi.ua",
            "gpa": 95.1
        }
    ]

    for student in test_students:

        students_db[next_id] = {
            **student,
            "id": next_id,
            "created_at": datetime.now().isoformat()
        }

        next_id += 1

    app.run(
        debug=True,
        port=5005
    )
