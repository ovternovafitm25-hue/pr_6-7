from flask import Flask
from flask import request
from flask import render_template_string
from flask import redirect
from flask import url_for
from flask import flash
from flask import abort

app = Flask(__name__)
app.secret_key = "blog-secret-key"

LIST_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Блог</title>
</head>
<body>

<h1>Публікації</h1>

{% with messages = get_flashed_messages() %}
{% if messages %}
<p style="color:green;">
{{ messages[0] }}
</p>
{% endif %}
{% endwith %}

{% for post in posts %}

<h3>
<a href="{{ url_for('post_detail', post_id=post.id) }}">
{{ post.title }}
</a>
</h3>

<p>{{ post.content }}</p>

<p>
{{ post.author }}
</p>

<a href="{{ url_for('post_edit', post_id=post.id) }}">
Редагувати
</a>

|

<a href="{{ url_for('post_delete', post_id=post.id) }}">
Видалити
</a>

<hr>

{% endfor %}

</body>
</html>
"""

DETAIL_TEMPLATE = """
<!DOCTYPE html>
<html>
<body>

<h1>{{ post.title }}</h1>

<p>{{ post.content }}</p>

<p>
Автор: {{ post.author }}
</p>

<p>
Дата: {{ post.created_at }}
</p>

<a href="{{ url_for('post_list') }}">
Назад
</a>

</body>
</html>
"""

EDIT_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
<title>Редагування</title>
</head>
<body>

<h1>Редагування публікації</h1>

<form method="POST">

<label>Заголовок</label>
<br>

<input
type="text"
name="title"
value="{{ post.title }}"
required
>

<br><br>

<label>Автор</label>
<br>

<input
type="text"
name="author"
value="{{ post.author }}"
required
>

<br><br>

<label>Зміст</label>
<br>

<textarea
name="content"
rows="10"
cols="50"
required
>{{ post.content }}</textarea>

<br><br>

<button type="submit">
Зберегти
</button>

</form>

</body>
</html>
"""

DELETE_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
<title>Видалення</title>
</head>
<body>

<h1>Підтвердження видалення</h1>

<p>

Ви дійсно бажаєте видалити

<strong>{{ post.title }}</strong>

?

</p>

<form method="POST">

<button type="submit"
style="color:red;">

Так, видалити

</button>

<a href="{{ url_for('post_detail',
                    post_id=post.id) }}">
Скасувати
</a>

</form>

</body>
</html>
"""

posts_db = [
    {
        "id": 1,
        "title": "Перша публікація",
        "content": "Зміст першої публікації",
        "author": "Іван",
        "created_at": "2025-01-15"
    },
    {
        "id": 2,
        "title": "Друга публікація",
        "content": "Зміст другої публікації",
        "author": "Марія",
        "created_at": "2025-01-20"
    }
]


@app.route("/posts")
def post_list():

    return render_template_string(
        LIST_TEMPLATE,
        posts=posts_db
    )


@app.route("/posts/<int:post_id>")
def post_detail(post_id):

    post = next(
        (p for p in posts_db
         if p["id"] == post_id),
        None
    )

    if not post:
        abort(404)

    return render_template_string(
        DETAIL_TEMPLATE,
        post=post
    )


@app.route("/posts/<int:post_id>/edit",
           methods=["GET", "POST"])
def post_edit(post_id):

    post = next(
        (p for p in posts_db
         if p["id"] == post_id),
        None
    )

    if not post:
        abort(404)

    if request.method == "POST":

        title = request.form.get(
            "title", ""
        ).strip()

        author = request.form.get(
            "author", ""
        ).strip()

        content = request.form.get(
            "content", ""
        ).strip()

        if not title or not author or not content:

            flash(
                "Усі поля повинні бути заповнені"
            )

            return redirect(
                url_for(
                    "post_edit",
                    post_id=post_id
                )
            )

        post["title"] = title
        post["author"] = author
        post["content"] = content

        flash(
            "Публікацію успішно оновлено"
        )

        return redirect(
            url_for(
                "post_detail",
                post_id=post_id
            )
        )

    return render_template_string(
        EDIT_TEMPLATE,
        post=post
    )


@app.route("/posts/<int:post_id>/delete",
           methods=["GET", "POST"])
def post_delete(post_id):

    post = next(
        (p for p in posts_db
         if p["id"] == post_id),
        None
    )

    if not post:
        abort(404)

    if request.method == "POST":

        posts_db.remove(post)

        flash(
            "Публікацію видалено"
        )

        return redirect(
            url_for("post_list")
        )

    return render_template_string(
        DELETE_TEMPLATE,
        post=post
    )


@app.errorhandler(404)
def not_found(error):

    return """
    <h1>404</h1>
    <p>Публікацію не знайдено</p>
    """, 404


if __name__ == "__main__":
    app.run(
        debug=True,
        port=5004
    )
