from flask import Flask
from flask import request
from flask import make_response
from flask import session
from flask import jsonify
from flask import redirect
from flask import url_for

app = Flask(__name__)

app.secret_key = "super-secret-key"

app.json.ensure_ascii = False


# ----------------------------
# Cookies
# ----------------------------

@app.route("/set-theme/<theme>")
def set_theme(theme):

    response = make_response(
        f"Тему {theme} збережено"
    )

    response.set_cookie(
        "theme",
        theme,
        max_age=60 * 60 * 24 * 30,
        httponly=True,
        samesite="Lax"
    )

    return response


@app.route("/get-theme")
def get_theme():

    theme = request.cookies.get(
        "theme",
        "light"
    )

    return jsonify({
        "theme": theme
    })


@app.route("/set-language/<lang>")
def set_language(lang):

    response = make_response(
        f"Мову {lang} збережено"
    )

    response.set_cookie(
        "language",
        lang,
        max_age=60 * 60 * 24 * 30,
        httponly=True,
        samesite="Lax"
    )

    return response


@app.route("/preferences")
def preferences():

    return jsonify({
        "theme": request.cookies.get("theme"),
        "language": request.cookies.get("language")
    })


# ----------------------------
# Session Cart
# ----------------------------

@app.route("/cart/add/<int:product_id>")
def add_to_cart(product_id):

    cart = session.get("cart", [])

    cart.append(product_id)

    session["cart"] = cart

    return jsonify({
        "message": "Товар додано",
        "cart": cart
    })


@app.route("/cart")
def view_cart():

    return jsonify({
        "cart": session.get("cart", [])
    })


@app.route("/cart/clear")
def clear_cart():

    session.pop("cart", None)

    return jsonify({
        "message": "Кошик очищено"
    })


# ----------------------------
# Login
# ----------------------------

@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        username = request.form.get(
            "username"
        )

        session["username"] = username

        return jsonify({
            "message": "Вхід успішний",
            "user": username
        })

    return """
    <h2>Авторизація</h2>

    <form method="POST">

        Ім'я:<br>

        <input type="text" name="username">

        <br><br>

        <button type="submit">
            Увійти
        </button>

    </form>
    """


@app.route("/logout")
def logout():

    session.pop("username", None)

    return jsonify({
        "message": "Вихід виконаний"
    })


@app.route("/profile")
def profile():

    username = session.get("username")

    if not username:

        return redirect(
            url_for("login")
        )

    return jsonify({
        "user": username
    })


# ----------------------------
# Products
# ----------------------------

products_db = {
    1: {
        "name": "Ноутбук",
        "price": 25000
    },
    2: {
        "name": "Смартфон",
        "price": 12000
    },
    3: {
        "name": "Навушники",
        "price": 2000
    }
}


if __name__ == "__main__":
    app.run(
        debug=True,
        port=5002
    )
