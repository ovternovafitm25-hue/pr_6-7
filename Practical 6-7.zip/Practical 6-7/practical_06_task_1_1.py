from flask import Flask, request, render_template_string, redirect, url_for

app = Flask(__name__)

BASE_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>{{ title }}</title>
</head>
<body>

<h1>{{ title }}</h1>

<nav>
    <a href="/">Головна</a> |
    <a href="/posts">Публікації</a> |
    <a href="/search">Пошук</a>
</nav>

<hr>

{{ content|safe }}

</body>
</html>
"""

posts_db = [
    {
        "id": 1,
        "title": "Вступ до Python",
        "content": "Python - потужна мова програмування",
        "author": "Іван"
    },
    {
        "id": 2,
        "title": "Flask для початківців",
        "content": "Flask - мікрофреймворк",
        "author": "Марія"
    },
    {
        "id": 3,
        "title": "REST API",
        "content": "REST - архітектурний стиль",
        "author": "Петро"
    }
]

next_id = 4


@app.route("/")
def index():
    return render_template_string(
        BASE_TEMPLATE,
        title="Головна",
        content="<p>Ласкаво просимо до блогу!</p>"
    )


@app.route("/posts")
def post_list():
    html = ""

    for post in posts_db:
        html += f"""
        <p>
            <a href="/posts/{post['id']}">
                {post['title']}
            </a>
        </p>
        """

    return render_template_string(
        BASE_TEMPLATE,
        title="Публікації",
        content=html
    )


@app.route("/posts/<int:post_id>")
def post_detail(post_id):

    post = next(
        (p for p in posts_db if p["id"] == post_id),
        None
    )

    if post is None:
        return "Публікацію не знайдено", 404

    return render_template_string(
        BASE_TEMPLATE,
        title=post["title"],
        content=f"""
        <p>{post['content']}</p>
        <p>Автор: {post['author']}</p>
        """
    )


@app.route("/posts/create", methods=["GET", "POST"])
def post_create():
    global next_id

    if request.method == "POST":

        posts_db.append({
            "id": next_id,
            "title": request.form.get("title"),
            "author": request.form.get("author"),
            "content": request.form.get("content")
        })

        next_id += 1

        return redirect(url_for("post_list"))

    form = """
    <form method="POST">

        <label>Заголовок:</label><br>
        <input type="text" name="title"><br><br>

        <label>Автор:</label><br>
        <input type="text" name="author"><br><br>

        <label>Зміст:</label><br>
        <textarea name="content"></textarea><br><br>

        <button type="submit">Створити</button>

    </form>
    """

    return render_template_string(
        BASE_TEMPLATE,
        title="Створення публікації",
        content=form
    )


@app.route("/search")
def search():
    q = request.args.get("q", "")
    return f"Результат пошуку: {q}"


@app.route("/archive/<int:year>/<int:month>")
def archive(year, month):
    return f"Архів: {month}/{year}"


@app.route("/user/<string:username>")
def user_profile(username):
    return f"Профіль користувача: {username}"


if __name__ == "__main__":
    app.run(debug=True, port=5000)
