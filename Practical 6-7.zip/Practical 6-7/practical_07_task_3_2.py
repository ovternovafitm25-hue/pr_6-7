from flask import Flask, request, jsonify
from datetime import datetime
from functools import wraps

app = Flask(__name__)
app.json.ensure_ascii = False

students_db = {}
next_id = 1


# ==========================================
# API Exception
# ==========================================

class APIError(Exception):

    def __init__(
        self,
        message,
        status_code=400,
        details=None
    ):
        self.message = message
        self.status_code = status_code
        self.details = details or {}


# ==========================================
# Serializer
# ==========================================

class StudentSerializer:

    @staticmethod
    def serialize(student, fields=None):

        data = {
            "id": student["id"],
            "name": student["name"],
            "group": student["group"],
            "email": student["email"],
            "gpa": student["gpa"],
            "created_at": student["created_at"]
        }

        if fields:

            filtered = {}

            for field in fields:

                if field in data:
                    filtered[field] = data[field]

            return filtered

        return data

    @staticmethod
    def deserialize(data):

        required = [
            "name",
            "group",
            "email",
            "gpa"
        ]

        missing = []

        for field in required:

            if field not in data:

                missing.append(field)

        if missing:

            raise APIError(
                "Відсутні обов'язкові поля",
                422,
                {"missing": missing}
            )

        try:

            gpa = float(data["gpa"])

        except ValueError:

            raise APIError(
                "GPA повинен бути числом",
                422
            )

        if gpa < 0 or gpa > 100:

            raise APIError(
                "GPA повинен бути від 0 до 100",
                422
            )

        return {
            "name": data["name"],
            "group": data["group"],
            "email": data["email"],
            "gpa": gpa
        }

    @staticmethod
    def serialize_list(students, fields=None):

        return [
            StudentSerializer.serialize(
                student,
                fields
            )
            for student in students
        ]


# ==========================================
# Middleware
# ==========================================

@app.before_request
def log_request():

    print(
        f"[{datetime.now()}] "
        f"{request.method} "
        f"{request.url}"
    )


@app.after_request
def add_headers(response):

    response.headers[
        "Access-Control-Allow-Origin"
    ] = "*"

    response.headers[
        "X-Request-Time"
    ] = datetime.now().isoformat()

    return response


# ==========================================
# API Key
# ==========================================

def require_api_key(f):

    @wraps(f)
    def wrapper(*args, **kwargs):

        api_key = request.headers.get(
            "X-API-Key"
        )

        if api_key != "secret-api-key-123":

            return jsonify({
                "error": "Невірний API-ключ"
            }), 401

        return f(
            *args,
            **kwargs
        )

    return wrapper


# ==========================================
# Routes
# ==========================================

@app.route(
    "/api/v2/students",
    methods=["GET"]
)
def get_students_v2():

    students = list(
        students_db.values()
    )

    search = request.args.get(
        "search",
        ""
    ).lower()

    if search:

        students = [
            student
            for student in students
            if search in student["name"].lower()
            or search in student["group"].lower()
            or search in student["email"].lower()
        ]

    sort_field = request.args.get(
        "sort",
        "name"
    )

    order = request.args.get(
        "order",
        "asc"
    )

    if sort_field in [
        "name",
        "group",
        "gpa"
    ]:

        reverse = (
            order == "desc"
        )

        students.sort(
            key=lambda x: x[sort_field],
            reverse=reverse
        )

    fields = request.args.get(
        "fields"
    )

    selected_fields = None

    if fields:

        selected_fields = [
            field.strip()
            for field in fields.split(",")
        ]

    result = StudentSerializer.serialize_list(
        students,
        selected_fields
    )

    return jsonify({
        "count": len(result),
        "students": result
    })


@app.route(
    "/api/v2/students",
    methods=["POST"]
)
@require_api_key
def create_student_v2():

    global next_id

    data = request.get_json()

    if not data:

        raise APIError(
            "Очікується JSON",
            400
        )

    student_data = (
        StudentSerializer.deserialize(
            data
        )
    )

    email_exists = any(
        student["email"]
        ==
        student_data["email"]
        for student
        in students_db.values()
    )

    if email_exists:

        raise APIError(
            "Email вже існує",
            422
        )

    student = {
        "id": next_id,
        **student_data,
        "created_at":
            datetime.now()
            .isoformat()
    }

    students_db[next_id] = student

    next_id += 1

    return jsonify(
        StudentSerializer.serialize(
            student
        )
    ), 201


# ==========================================
# Error Handling
# ==========================================

@app.errorhandler(APIError)
def handle_api_error(error):

    response = {
        "error": error.message,
        "status": error.status_code,
        "details": error.details,
        "timestamp": (
            datetime.now()
            .isoformat()
        )
    }

    return jsonify(
        response
    ), error.status_code


@app.errorhandler(404)
def not_found(error):

    return jsonify({
        "error": "Ресурс не знайдено",
        "status": 404
    }), 404


@app.errorhandler(400)
def bad_request(error):

    return jsonify({
        "error": "Некоректний запит",
        "status": 400
    }), 400


# ==========================================
# Test Data
# ==========================================

if __name__ == "__main__":

    test_students = [
        {
            "name": "Іваненко О.",
            "group": "КІ-21",
            "email": "ivan@kpi.ua",
            "gpa": 85.5
        },
        {
            "name": "Петренко М.",
            "group": "КІ-21",
            "email": "petro@kpi.ua",
            "gpa": 92
        },
        {
            "name": "Коваль Л.",
            "group": "КІ-22",
            "email": "koval@kpi.ua",
            "gpa": 95.1
        }
    ]

    for student in test_students:

        students_db[next_id] = {
            **student,
            "id": next_id,
            "created_at":
                datetime.now()
                .isoformat()
        }

        next_id += 1

    app.run(
        debug=True,
        port=5006
    )
