from flask import Flask, request, jsonify
from functools import wraps

app = Flask(__name__)

items_db = {
    1: {
        "id": 1,
        "name": "Ноутбук",
        "price": 25000,
        "category": "електроніка"
    },
    2: {
        "id": 2,
        "name": "Книга Python",
        "price": 500,
        "category": "книги"
    },
    3: {
        "id": 3,
        "name": "Навушники",
        "price": 2000,
        "category": "електроніка"
    }
}

next_id = 4


def validate_json(required_fields):

    def decorator(f):

        @wraps(f)
        def wrapper(*args, **kwargs):

            data = request.get_json(silent=True)

            if data is None:
                return jsonify({
                    "error": "Очікується JSON"
                }), 400

            missing = [
                field
                for field in required_fields
                if field not in data
            ]

            if missing:
                return jsonify({
                    "error": f"Відсутні поля: {', '.join(missing)}"
                }), 400

            return f(*args, **kwargs)

        return wrapper

    return decorator


@app.route("/api/items", methods=["GET"])
def get_items():

    items = list(items_db.values())

    category = request.args.get("category")

    min_price = request.args.get("min_price", type=float)

    max_price = request.args.get("max_price", type=float)

    if category:
        items = [
            item for item in items
            if item["category"] == category
        ]

    if min_price is not None:
        items = [
            item for item in items
            if item["price"] >= min_price
        ]

    if max_price is not None:
        items = [
            item for item in items
            if item["price"] <= max_price
        ]

    return jsonify({
        "count": len(items),
        "items": items
    })


@app.route("/api/items", methods=["POST"])
@validate_json(["name", "price", "category"])
def create_item():

    global next_id

    data = request.get_json()

    if not data["name"].strip():
        return jsonify({
            "error": "Порожня назва"
        }), 400

    if float(data["price"]) <= 0:
        return jsonify({
            "error": "Ціна повинна бути більше 0"
        }), 400

    item = {
        "id": next_id,
        "name": data["name"],
        "price": data["price"],
        "category": data["category"]
    }

    items_db[next_id] = item

    next_id += 1

    return jsonify(item), 201


@app.route("/api/items/<int:item_id>", methods=["GET"])
def get_item(item_id):

    item = items_db.get(item_id)

    if not item:
        return jsonify({
            "error": "Не знайдено"
        }), 404

    return jsonify(item)


@app.route("/api/items/<int:item_id>", methods=["PUT"])
@validate_json(["name", "price", "category"])
def update_item(item_id):

    if item_id not in items_db:
        return jsonify({
            "error": "Не знайдено"
        }), 404

    data = request.get_json()

    items_db[item_id].update({
        "name": data["name"],
        "price": data["price"],
        "category": data["category"]
    })

    return jsonify(items_db[item_id])


@app.route("/api/items/<int:item_id>", methods=["DELETE"])
def delete_item(item_id):

    if item_id not in items_db:
        return jsonify({
            "error": "Не знайдено"
        }), 404

    del items_db[item_id]

    return "", 204


@app.errorhandler(404)
def not_found(error):
    return jsonify({
        "error": "Ресурс не знайдено"
    }), 404


@app.errorhandler(400)
def bad_request(error):
    return jsonify({
        "error": "Некоректний запит"
    }), 400


if __name__ == "__main__":
    app.run(debug=True, port=5001)
