from flask import Flask, request, render_template_string
from flask import redirect, url_for, flash, abort
from datetime import datetime

app = Flask(__name__)
app.secret_key = "blog-secret-key"

LIST_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Блог</title>
</head>
<body>

<h1>Публікації</h1>

{% with messages = get_flashed_messages() %}
    {% if messages %}
        <div style="color: green;">
            {{ messages[0] }}
        </div>
    {% endif %}
{% endwith %}

<a href="{{ url_for('post_create') }}">
    + Нова публікація
</a>

<hr>

{% for post in posts %}

<article>

<h2>
<a href="{{ url_for('post_detail', post_id=post.id) }}">
{{ post.title }}
</a>
</h2>

<p>
{{ post.content[:100] }}
</p>

<small>
{{ post.author }} |
{{ post.created_at }}
</small>

</article>

<hr>

{% endfor %}

<div>
{% if page > 1 %}
<a href="{{ url_for('post_list', page=page-1) }}">
Попередня
</a>
{% endif %}

|

<a href="{{ url_for('post_list', page=page+1) }}">
Наступна
</a>

</div>

</body>
</html>
"""

FORM_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>{{ form_title }}</title>
</head>
<body>

<h1>{{ form_title }}</h1>

<form method="POST">

<label>Заголовок:</label>
<br>

<input
type="text"
name="title"
required
style="width:400px;"
>

<br><br>

<label>Автор:</label>
<br>

<input
type="text"
name="author"
required
>

<br><br>

<label>Зміст:</label>
<br>

<textarea
name="content"
rows="10"
cols="50"
required
></textarea>

<br><br>

<button type="submit">
Створити
</button>

</form>

</body>
</html>
"""

DETAIL_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
<title>{{ post.title }}</title>
</head>
<body>

<h1>{{ post.title }}</h1>

<p>{{ post.content }}</p>

<p>
<b>Автор:</b>
{{ post.author }}
</p>

<p>
<b>Дата:</b>
{{ post.created_at }}
</p>

<a href="{{ url_for('post_list') }}">
Повернутися
</a>

</body>
</html>
"""

posts_db = []

next_id = 1


@app.route("/posts")
def post_list():

    page = int(request.args.get("page", 1))
    per_page = 5

    start = (page - 1) * per_page
    end = start + per_page

    posts = posts_db[start:end]

    return render_template_string(
        LIST_TEMPLATE,
        posts=posts,
        page=page
    )


@app.route("/posts/<int:post_id>")
def post_detail(post_id):

    post = next(
        (p for p in posts_db if p["id"] == post_id),
        None
    )

    if not post:
        abort(404)

    return render_template_string(
        DETAIL_TEMPLATE,
        post=post
    )


@app.route("/posts/create",
           methods=["GET", "POST"])
def post_create():

    global next_id

    if request.method == "POST":

        title = request.form.get("title", "").strip()
        author = request.form.get("author", "").strip()
        content = request.form.get("content", "").strip()

        if not title or not author or not content:
            flash("Усі поля обов'язкові")
            return redirect(
                url_for("post_create")
            )

        post = {
            "id": next_id,
            "title": title,
            "author": author,
            "content": content,
            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M")
        }

        posts_db.append(post)

        next_id += 1

        flash("Публікацію успішно створено")

        return redirect(
            url_for(
                "post_detail",
                post_id=post["id"]
            )
        )

    return render_template_string(
        FORM_TEMPLATE,
        form_title="Створення публікації"
    )


if __name__ == "__main__":
    app.run(debug=True, port=5003)
